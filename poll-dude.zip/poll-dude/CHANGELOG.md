# Changelog
[1.0.0]First release
Create the polls by generating shortcodes embedded in your posts. 
Showing one selected poll as a widget.
With reCaptchaV2 to prevent robots accessing. 
The color of each answer voted-bar can be set differently.
